  #include "CustomDS.h"

// ============================================================================
// Buffer Class Implementation
// ============================================================================
Buffer::Buffer() {
  _inx = 0;
  _full = false;
  _m = 1.0f;
  _c = 0.0f;
  _acc = 0.0f;
  
  for (byte i = 0; i < N; i++) {
    _data[i] = 0.0f;
    _dataf[i] = 0.0f;
  }
}

void Buffer::add(float value) {
  _data[_inx] = value;
  
  // Apply conversion factor
  _dataf[_inx] = conval(value);
  
  _inx = (_inx + 1) & Nmask;
  
  if (_inx == 0) {
    _full = true;
  }
}

byte Buffer::inx(void) {
  return _inx;
}

bool Buffer::isFull(void) {
  return _full;
}

float Buffer::val(byte index, bool filtered) {
  if (filtered) {
    return _dataf[index & Nmask];
  } else {
    return _data[index & Nmask];
  }
}

float Buffer::valf(byte index, bool filtered) {
  return val(index, filtered);
}

void Buffer::setconvfac(float m, float c) {
  _m = m;
  _c = c;
}

float Buffer::conval(float raw) {
  return _m * raw + _c;
}

// ============================================================================
// OutDataBuffer4Float Class Implementation
// ============================================================================
OutDataBuffer4Float::OutDataBuffer4Float() {
  _sz = 0;
}

void OutDataBuffer4Float::newPacket() {
  _sz = 0;
}

void OutDataBuffer4Float::add(float value) {
  if (_sz < 64) {
    _data[_sz].num = value;
    _sz++;
  }
}

byte OutDataBuffer4Float::sz() {
  return _sz;
}

byte OutDataBuffer4Float::getByte(byte index) {
  if (index >= _sz * 4) {
    return 0;
  }
  
  byte floatIndex = index / 4;
  byte byteIndex = index % 4;
  
  return _data[floatIndex].bytes[byteIndex];
}