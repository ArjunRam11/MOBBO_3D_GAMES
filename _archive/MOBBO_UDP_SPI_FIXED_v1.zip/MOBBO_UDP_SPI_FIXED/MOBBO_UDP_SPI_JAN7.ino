/*
 * MOBBO ESP32 Firmware — ADS1261 ISR-driven, 1250 Hz per channel
 *
 * UDP packet layout matches the original ESP8266 sinboard firmware exactly:
 *
 *  SendStreamPacketforGame()   — primary stream, called by SendDeviceData()
 *    [0]      id
 *    [1]      status1
 *    [2]      status2
 *    [3]      status3
 *    [4–7]    t      (timestamp, float, seconds)
 *    [8–11]   f1
 *    [12–15]  f2
 *    [16–19]  f3
 *    [20–23]  f4
 *    [24–27]  COPx
 *    [28–31]  COPy
 *    Total = 36 bytes  →  struct.unpack('4c8f', data)
 *
 *  SendStreamPacketforDisplay()  — 32 bytes, no timestamp, includes W
 *    [0–3]    id,s1,s2,s3
 *    [4–7]    f1 … [16–19] f4
 *    [20–23]  COPx  [24–27] COPy  [28–31] W
 *    Total = 32 bytes  →  struct.unpack('4c7f', data)
 *
 *  SendStreamPacketforValidation()  — 34 bytes, includes W + ButtonState (int16)
 *
 *  SendSinglePacketforGameandDisplay()  — 36 bytes, all floats zeroed
 *  SendSinglePacketforValidation()      — 34 bytes, all zeroed
 *
 * status1 bits (same as sinboard):
 *   bit7 = LED   bit6 = VIBRATE   bit5 = STREAM
 *
 * Hardware: ESP32 DOIT DevKit + ADS1261 (SPI) + RGB LED + Motor
 */

#include <WiFi.h>
#include <WiFiUdp.h>
#include <SPI.h>
#include "variable_udp.h"
#include "CustomDS.h"

// ============================================================================
// PIN DEFINITIONS  (ESP32 DOIT DevKit)
// ============================================================================
#define CS_PIN      5
#define DRDY_PIN    4
#define RESET_PIN   16
#define MOSI_PIN    23
#define MISO_PIN    19
#define SCK_PIN     18

// RGB LED (active-HIGH — change to LOW if your board is active-low)
#define RED_LED_PIN    12
#define GREEN_LED_PIN  14
#define BLUE_LED_PIN   13

// Motor / vibration
#define MOTOR_PIN      22

// W_PIN equivalent — digital input used for COP validation button
// Connect your validation button here; pulled HIGH internally.
#define W_PIN          21

// ============================================================================
// ADS1261 COMMAND / REGISTER DEFINITIONS
// ============================================================================
#define ADS1261_CMD_RESET   0x06
#define ADS1261_CMD_START   0x08
#define ADS1261_CMD_STOP    0x0A
#define ADS1261_CMD_RDATA   0x12
#define ADS1261_CMD_RREG    0x20
#define ADS1261_CMD_WREG    0x40

#define ADS1261_REG_ID      0x00
#define ADS1261_REG_MODE0   0x02
#define ADS1261_REG_MODE1   0x03
#define ADS1261_REG_MODE2   0x04
#define ADS1261_REG_REF     0x06
#define ADS1261_REG_PGA     0x10
#define ADS1261_REG_INPMUX  0x11

// 20 kSPS Sinc1 → ~1250 Hz effective per channel across 4 ch mux
#define MODE0_SINC1_20000SPS  0x82
#define MODE1_NORMAL          0x00
#define REF_INTERNAL          0x10
#define PGA_GAIN32            0x05

// ============================================================================
// RING BUFFER  (ISR → loop handoff)
//   4 channels × 256 frames, power-of-2 size for fast index wrap
// ============================================================================
#define NUM_CHANNELS  4
#define RING_SIZE     256
#define RING_MASK     (RING_SIZE - 1)

static volatile int32_t  ring_buf[NUM_CHANNELS][RING_SIZE];
static volatile uint16_t ring_wr  = 0;
static volatile uint16_t ring_rd  = 0;

// ADS1261 MUX pin pairs (AIN_P, AIN_N) for channels 0–3
static const uint8_t MUX_P[NUM_CHANNELS] = {1, 3, 5, 7};
static const uint8_t MUX_N[NUM_CHANNELS] = {2, 4, 6, 8};

static volatile uint8_t  current_ch  = 0;
static volatile bool     acq_paused  = false;
static volatile bool     in_isr      = false;
static volatile uint32_t rb_overflow = 0;

// ============================================================================
// BOARD IDENTITY
// ============================================================================
#define BOARD_ID  55     // ← change per board (e.g. 11, 44, 55, 68, 88)
byte board_id = BOARD_ID;

// ============================================================================
// PACKET COMMAND DEFINITIONS  (same nibble scheme as sinboard)
// ============================================================================
#define SET_ID        0x00
#define STREAM_OFF    0x10   // det=0 → stop,  det=1 → start
#define LED_RED_OFF   0x20   // det=0 → off,   det=1 → on
#define LED_GREEN_OFF 0xA0   // det=0 → off,   det=1 → on  (new, Python-ignored)
#define LED_BLUE_OFF  0xB0   // det=0 → off,   det=1 → on  (new, Python-ignored)
#define MOTOR_OFF     0x30   // det=0 → off,   det=1 → on
#define RESET_TIMER   0x40
#define GET_STATUS    0x50
#define REGISTER      0x80
#define RESET_BOARD   0xC0   // ESP.restart()

// ============================================================================
// HARDWARE STATE
// ============================================================================
bool led_red       = false;
bool led_green     = false;
bool led_blue      = false;
bool motor_running = false;
unsigned long motor_start_time     = 0;
const unsigned long motor_duration = 2000;  // ms auto-off

// Validation button state — mirrors sinboard's W_ButtonState
union Intbytes_esp {
  int16_t Ival;
  byte    Ibytes[2];
} W_ButtonState;

// ============================================================================
// SPI
// ============================================================================
SPISettings spiSettings(10000000, MSBFIRST, SPI_MODE1);
SPIClass   *hspi = NULL;

// ============================================================================
// SAMPLING RATE TRACKER
// ============================================================================
struct SamplingStats {
  uint32_t      sample_count;
  unsigned long last_report_time;
  void reset() { sample_count = 0; last_report_time = millis(); }
  void update() {
    sample_count++;
    unsigned long now = millis();
    if (now - last_report_time >= 1000) {
      float rate = (sample_count * 1000.0f) / (now - last_report_time);
      Serial.print("Frame rate: "); Serial.print(rate, 1);
      Serial.print(" Hz  |  ring overflow events: "); Serial.println(rb_overflow);
      sample_count     = 0;
      last_report_time = now;
    }
  }
} sampling_stats;

// ============================================================================
// LOW-LEVEL SPI HELPERS
// ============================================================================
static inline void spiBegin() { digitalWrite(CS_PIN, LOW);  }
static inline void spiEnd()   { digitalWrite(CS_PIN, HIGH); }

static inline void writeRegister(uint8_t reg, uint8_t val) {
  spiBegin();
  hspi->transfer(ADS1261_CMD_WREG | reg);
  hspi->transfer(val);
  spiEnd();
}

static inline uint8_t readRegister(uint8_t reg) {
  spiBegin();
  hspi->transfer(ADS1261_CMD_RREG | reg);
  hspi->transfer(0x00);
  uint8_t v = hspi->transfer(0x00);
  spiEnd();
  return v;
}

static inline void sendCommand(uint8_t cmd) {
  spiBegin();
  hspi->transfer(cmd);
  spiEnd();
}

static inline void selectDiff(uint8_t ainp, uint8_t ainn) {
  spiBegin();
  hspi->transfer(ADS1261_CMD_WREG | ADS1261_REG_INPMUX);
  hspi->transfer(((ainp & 0x0F) << 4) | (ainn & 0x0F));
  spiEnd();
}

// ============================================================================
// FAST 24-BIT ADC READ  (called from ISR and blocking calibration)
// ============================================================================
static inline int32_t readADC24_ISR() {
  spiBegin();
  hspi->transfer(ADS1261_CMD_RDATA);
  hspi->transfer(0x00);              // status byte (discard)
  uint8_t b2 = hspi->transfer(0x00);
  uint8_t b1 = hspi->transfer(0x00);
  uint8_t b0 = hspi->transfer(0x00);
  spiEnd();

  int32_t val = ((int32_t)b2 << 16) | ((int32_t)b1 << 8) | (int32_t)b0;
  if (val & 0x800000) val |= 0xFF000000;  // sign-extend 24 → 32 bit
  return val;
}

// ============================================================================
// DRDY ISR  — fires on every falling edge from ADS1261
//   Reads the completed conversion, switches MUX to the next channel,
//   and writes one complete 4-channel frame to the ring buffer when
//   channel 0 rolls over (i.e., after every 4th sample).
// ============================================================================
void IRAM_ATTR DRDY_ISR() {
  if (in_isr) return;
  in_isr = true;

  int32_t raw     = readADC24_ISR();
  uint8_t next_ch = (current_ch + 1) % NUM_CHANNELS;
  selectDiff(MUX_P[next_ch], MUX_N[next_ch]);

  ring_buf[current_ch][ring_wr] = raw;

  if (next_ch == 0) {                          // completed one full frame
    uint16_t next_wr = (ring_wr + 1) & RING_MASK;
    if (next_wr == ring_rd) {
      acq_paused = true;                       // overflow: signal loop() to flush
      rb_overflow++;
    } else {
      ring_wr = next_wr;
    }
  }

  current_ch = next_ch;
  in_isr     = false;
}

// ============================================================================
// START / STOP ACQUISITION
// ============================================================================
static void stopAcq() {
  detachInterrupt(digitalPinToInterrupt(DRDY_PIN));
  sendCommand(ADS1261_CMD_STOP);
}

static void startAcq() {
  current_ch = 0;
  selectDiff(MUX_P[0], MUX_N[0]);
  delayMicroseconds(100);
  attachInterrupt(digitalPinToInterrupt(DRDY_PIN), DRDY_ISR, FALLING);
  sendCommand(ADS1261_CMD_START);
}

// ============================================================================
// ADS1261 CONFIGURATION
// ============================================================================
void ConfigADS() {
  Serial.println("Configuring ADS1261 for ~1250 Hz / channel...");
  writeRegister(ADS1261_REG_MODE0, MODE0_SINC1_20000SPS);
  writeRegister(ADS1261_REG_MODE1, MODE1_NORMAL);
  writeRegister(ADS1261_REG_MODE2, 0x00);
  writeRegister(ADS1261_REG_REF,   REF_INTERNAL);
  writeRegister(ADS1261_REG_PGA,   PGA_GAIN32);

  uint8_t mode0_rb = readRegister(ADS1261_REG_MODE0);
  uint8_t pga_rb   = readRegister(ADS1261_REG_PGA);
  Serial.print("  MODE0: 0x"); Serial.println(mode0_rb, HEX);
  Serial.print("  PGA:   0x"); Serial.println(pga_rb,   HEX);
  if (mode0_rb == MODE0_SINC1_20000SPS && pga_rb == PGA_GAIN32)
    Serial.println("  Config OK");
  else
    Serial.println("  WARNING: Config verify failed — check SPI wiring");
}

// ============================================================================
// BLOCKING ADC READ  (setup / calibration only, never called from loop)
// ============================================================================
static int32_t blockingReadOnce() {
  unsigned long t0 = millis();
  while (digitalRead(DRDY_PIN) == HIGH) {
    if (millis() - t0 > 10) return 0;
  }
  return readADC24_ISR();
}

// ============================================================================
// CALIBRATION — raw ADC tare offsets (Lc1Off … Lc4Off)
//   Mirrors sinboard GetLCOffsets(): 100-sample average per channel.
//   Each channel is read sequentially (blockingReadOnce after selectDiff).
// ============================================================================
float GetLCoff(uint8_t ainp, uint8_t ainn) {
  Serial.print("Zeroing LC"); Serial.print((ainp + 1) / 2); Serial.print("... ");
  selectDiff(ainp, ainn);
  delayMicroseconds(200);
  for (int i = 0; i < 5; i++) blockingReadOnce();   // flush pipeline

  long long acc  = 0;
  int       good = 0;
  for (int i = 0; i < 100; i++) {
    int32_t v = blockingReadOnce();
    if (v != 0) { acc += v; good++; }
  }
  if (good == 0) { Serial.println(" FAILED!"); return 0.0f; }
  float offset = (float)acc / (float)good;
  Serial.print(" OK (offset="); Serial.print(offset, 1); Serial.println(")");
  return offset;
}

// ============================================================================
// CALIBRATION — force offset tare (f1off … f4off)
//   Mirrors sinboard GetForceOffset(): applies gain/intercept to 100 raw
//   samples and averages the resulting force value.
// ============================================================================
float GetForceoff(uint8_t ainp, uint8_t ainn, float gain, float intercept_off) {
  Serial.print("Zeroing Force "); Serial.print((ainp + 1) / 2); Serial.print("... ");
  selectDiff(ainp, ainn);
  delayMicroseconds(200);
  for (int i = 0; i < 5; i++) blockingReadOnce();

  float acc = 0.0f;
  int   cnt = 0;
  for (int i = 0; i < 100; i++) {
    int32_t v = blockingReadOnce();
    if (v != 0) {
      // Same formula as sinboard GetForceOffset():
      //   f = (raw - LcOff) * gain + intercept_off
      acc += ((float)v - intercept_off) * gain;
      cnt++;
    }
  }
  if (cnt == 0) { Serial.println(" FAILED!"); return 0.0f; }
  float foff = acc / (float)cnt;
  Serial.print(" OK (foff="); Serial.print(foff, 2); Serial.println(")");
  return foff;
}

// ============================================================================
// INIT SENSOR VALUES  — identical to sinboard InitSensorVals()
// ============================================================================
void InitSensorVals() {
  count = 0;
  t.fval = f1.fval = f2.fval = f3.fval = f4.fval = 0.0f;
  COPx.fval = COPy.fval = W.fval = _zero.fval      = 0.0f;
  f1_filt   = f2_filt   = f3_filt = f4_filt        = 0.0f;
}

// ============================================================================
// PROCESS RING BUFFER FRAMES
//   Drains the ring buffer.  For each frame, applies the calibration formula
//   from sinboard ReadLoadCellValues():
//       f = (raw - LcNOff) * gainBN  −  fNoff
//   Updates f1…f4 with the most recent converted value.
//   Returns number of frames processed (0 = no new data → skip send).
// ============================================================================
uint32_t processFrames() {
  uint32_t processed = 0;

  while (ring_rd != ring_wr) {
    uint16_t idx = ring_rd;

    int32_t raw[NUM_CHANNELS];
    noInterrupts();
    for (int ch = 0; ch < NUM_CHANNELS; ch++) raw[ch] = ring_buf[ch][idx];
    ring_rd = (ring_rd + 1) & RING_MASK;
    interrupts();

    float fn;

    // f = (raw - LcOff) * gain − foff
    // SMOOTH_ALPHA = 1.0 → pass-through (no smoothing), matches sinboard default
    fn = ((float)raw[0] - Lc1Off) * gainB11 - f1off;
    f1_filt = f1_filt + SMOOTH_ALPHA * (fn - f1_filt);
    f1.fval = f1_filt;

    fn = ((float)raw[1] - Lc2Off) * gainB12 - f2off;
    f2_filt = f2_filt + SMOOTH_ALPHA * (fn - f2_filt);
    f2.fval = f2_filt;

    fn = ((float)raw[2] - Lc3Off) * gainB13 - f3off;
    f3_filt = f3_filt + SMOOTH_ALPHA * (fn - f3_filt);
    f3.fval = f3_filt;

    fn = ((float)raw[3] - Lc4Off) * gainB14 - f4off;
    f4_filt = f4_filt + SMOOTH_ALPHA * (fn - f4_filt);
    f4.fval = f4_filt;

    processed++;
  }

  return processed;
}

// ============================================================================
// UpdateCOP  — identical formula to sinboard DevFunctions.ino
// ============================================================================
void UpdateCOP() {
  W.fval = f1.fval + f2.fval + f3.fval + f4.fval;

  if (W.fval > 1.0f) {
    COPx.fval = (-1.0f * ((((f1.fval + f4.fval) - (f3.fval + f2.fval)) / W.fval) * L_HALF));
    COPy.fval = (-1.0f * ((((f3.fval + f4.fval) - (f2.fval + f1.fval)) / W.fval) * B_HALF));
  } else {
    COPx.fval = 0.0f;
    COPy.fval = 0.0f;
  }

  // Serial debug — mirrors sinboard output
  Serial.print(COPx.fval); Serial.print(",");
  Serial.print(COPy.fval); Serial.print(",");
  Serial.println(W.fval);
}

// ============================================================================
// UpdateRGBLED
// ============================================================================
void UpdateRGBLED() {
  digitalWrite(RED_LED_PIN,   led_red   ? HIGH : LOW);
  digitalWrite(GREEN_LED_PIN, led_green ? HIGH : LOW);
  digitalWrite(BLUE_LED_PIN,  led_blue  ? HIGH : LOW);
}

// ============================================================================
// UpdateMotor  — auto-off after motor_duration ms
// ============================================================================
void UpdateMotor() {
  if (motor_running && millis() - motor_start_time >= motor_duration) {
    motor_running = false;
    digitalWrite(MOTOR_PIN, LOW);
    Serial.println("Motor stopped (timeout)");
  }
}

void StartMotor() {
  motor_running    = true;
  motor_start_time = millis();
  digitalWrite(MOTOR_PIN, HIGH);
  Serial.println("Motor started");
}

// ============================================================================
// UpdateStatusBytes  — matches sinboard DevFunctions.ino exactly
//   status1: bit7=LED  bit6=VIBRATE  bit5=STREAM
//   status2: board_id  (physical identity, constant)
//   status3: 0x00
// ============================================================================
void UpdateStatusBytes() {
  status1 = 0x00;
  status2 = (byte)board_id;
  status3 = 0x00;

  if (led_red)       status1 |= 0x80;   // LED bit  (sinboard used single led flag)
  if (motor_running) status1 |= 0x40;   // VIBRATE bit  (motor replaces vibrator)
  if (streaming)     status1 |= 0x20;   // STREAM bit
}

// ============================================================================
// UDP HELPERS
// ============================================================================
void SendFloatBytes(WiFiUDP &udp, FloatBytes_ud fd) {
  for (int i = 0; i < 4; i++) udp.write(fd.fbytes[i]);
}

void SendIntBytes(WiFiUDP &udp, Intbytes_esp id) {
  udp.write(id.Ibytes[0]);
  udp.write(id.Ibytes[1]);
}

// ============================================================================
// STREAM PACKET — GAME  (sinboard primary, 36 bytes)
//   struct.unpack('4c8f', data)  on Python side
//   [0–3]    id, status1, status2, status3
//   [4–7]    t        ← timestamp (seconds, float)
//   [8–11]   f1  [12–15] f2  [16–19] f3  [20–23] f4
//   [24–27]  COPx
//   [28–31]  COPy
//   Total = 4 + 8×4 = 36 bytes
// ============================================================================
void SendStreamPacketforGame() {
  if (!python_discovered) return;  // no client yet — don't send to 0.0.0.0
  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(id);
  udpClient.write(status1);
  udpClient.write(status2);
  udpClient.write(status3);
  SendFloatBytes(udpClient, t);
  SendFloatBytes(udpClient, f1);
  SendFloatBytes(udpClient, f2);
  SendFloatBytes(udpClient, f3);
  SendFloatBytes(udpClient, f4);
  SendFloatBytes(udpClient, COPx);
  SendFloatBytes(udpClient, COPy);
  //W intentionally omitted — matches sinboard SendStreamPacketforGame()
  udpClient.endPacket();
}

// ============================================================================
// STREAM PACKET — DISPLAY  (32 bytes, no timestamp, includes W)
//   struct.unpack('4c7f', data)  on Python side
//   [0–3]    id, status1, status2, status3
//   [4–7]    f1  [8–11] f2  [12–15] f3  [16–19] f4
//   [20–23]  COPx  [24–27] COPy  [28–31] W
// ============================================================================
void SendStreamPacketforDisplay() {
  if (!python_discovered) return;
  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(id);
  udpClient.write(status1);
  udpClient.write(status2);
  udpClient.write(status3);
  SendFloatBytes(udpClient, f1);
  SendFloatBytes(udpClient, f2);
  SendFloatBytes(udpClient, f3);
  SendFloatBytes(udpClient, f4);
  SendFloatBytes(udpClient, COPx);
  SendFloatBytes(udpClient, COPy);
  SendFloatBytes(udpClient, W);
  udpClient.endPacket();
}

// ============================================================================
// STREAM PACKET — VALIDATION  (34 bytes, includes W + button state int16)
//   [0–3]    id, status1, status2, status3
//   [4–31]   f1,f2,f3,f4,COPx,COPy,W  (7 floats = 28 bytes)
//   [32–33]  W_ButtonState (int16, 2 bytes)
// ============================================================================
void SendStreamPacketforValidation() {
  if (!python_discovered) return;
  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(id);
  udpClient.write(status1);
  udpClient.write(status2);
  udpClient.write(status3);
  SendFloatBytes(udpClient, f1);
  SendFloatBytes(udpClient, f2);
  SendFloatBytes(udpClient, f3);
  SendFloatBytes(udpClient, f4);
  SendFloatBytes(udpClient, COPx);
  SendFloatBytes(udpClient, COPy);
  SendFloatBytes(udpClient, W);
  SendIntBytes(udpClient, W_ButtonState);
  udpClient.endPacket();
}

// ============================================================================
// SINGLE (status-only) PACKETS  — all float fields zeroed
// ============================================================================
void SendSinglePacketforGameandDisplay() {
  if (!python_discovered) return;
  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(id);
  udpClient.write(status1);
  udpClient.write(status2);
  udpClient.write(status3);
  // 8 zeroed floats = 32 bytes  (same size as Game packet floats)
  for (int i = 0; i < 8; i++) SendFloatBytes(udpClient, _zero);
  udpClient.endPacket();
}

void SendSinglePacketforValidation() {
  if (!python_discovered) return;
  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(id);
  udpClient.write(status1);
  udpClient.write(status2);
  udpClient.write(status3);
  for (int i = 0; i < 8; i++) SendFloatBytes(udpClient, _zero);
  udpClient.endPacket();
}

// ============================================================================
// SendDeviceData  — mirrors sinboard default exactly:
//   streaming      → SendStreamPacketforGame()
//   individualpacket (not streaming) → SendSinglePacketforGameandDisplay()
// ============================================================================
void SendDeviceData() {
  if (streaming) {
    SendStreamPacketforGame();
  } else if (individualpacket) {
    SendSinglePacketforGameandDisplay();
    individualpacket = false;
  }
}

// ============================================================================
// REGISTRATION RESPONSE  — identical to sinboard SendRegistrationRequest()
// ============================================================================
void SendRegistrationRequest() {

  Serial.print("Replying to: ");
  Serial.print(clientIP);
  Serial.print(":");
  Serial.println(clientPort);

  udpClient.beginPacket(clientIP, clientPort);
  udpClient.write(0x00);
  udpClient.write(0x80);
  for (int i = 0; i < 30; i++) udpClient.write(0x00);
  udpClient.endPacket();
}

// ============================================================================
// RECEIVE & HANDLE INCOMING UDP COMMANDS
//   Matches sinboard ReceiveHandleIncomingData() command set exactly.
//   Also handles the new RGB LED / motor commands and "Hey!mobbos" discovery.
// ============================================================================
void ReceiveHandleIncomingData() {
  int pcktSz = udpClient.parsePacket();
  if (pcktSz == 0) return;  // nothing arrived — exit immediately

  // Capture sender BEFORE read() drains the buffer
  IPAddress senderIP   = udpClient.remoteIP();
  uint16_t  senderPort = udpClient.remotePort();

  Serial.print("[UDP] packet from ");
  Serial.print(senderIP);
  Serial.print(":");
  Serial.print(senderPort);
  Serial.print("  size=");
  Serial.println(pcktSz);

  // Read ONCE — original code called read() twice, second call always got 0 bytes
  pcktSz = udpClient.read(incomingPacket, 31);
  if (pcktSz == 0) {
    Serial.println("[UDP] read() returned 0 — empty packet, ignoring");
    return;
  }

  // ── DISCOVERY HANDLER ──────────────────────────────────────────────────
  // Python sends "Hey!mobbos" (10 bytes) or "Hey Mobbos!" (11 bytes) as
  // a broadcast to discover boards.  The sinboard had no explicit handler;
  // it accidentally fell into RESET_TIMER (0x40) because 'H' = 0x48, and
  // since streaming was already true it replied with a stream packet on
  // the next loop() iteration using remoteIP() which stayed valid on
  // ESP8266.  On ESP32 remoteIP() goes stale after read(), so we must
  // handle this explicitly: store the client address, send an immediate
  // reply, and ensure streaming targets the correct IP.
  // ────────────────────────────────────────────────────────────────────────
  if (pcktSz >= 4 &&
      incomingPacket[0] == 'H' &&
      incomingPacket[1] == 'e' &&
      incomingPacket[2] == 'y') {

    // Store the Python client address for all future UDP replies
    clientIP   = senderIP;
    clientPort = senderPort;
    python_discovered = true;

    Serial.print("[DISCOVERY] Python client registered @ ");
    Serial.print(clientIP);
    Serial.print(":");
    Serial.println(clientPort);

    // Send an immediate discovery reply so Python's recvfrom() picks us up.
    // Use the Display format (32 bytes = 4c7f) which Python already handles.
    udpClient.beginPacket(clientIP, clientPort);
    udpClient.write(id);
    udpClient.write(status1);
    udpClient.write(status2);
    udpClient.write(status3);
    SendFloatBytes(udpClient, f1);
    SendFloatBytes(udpClient, f2);
    SendFloatBytes(udpClient, f3);
    SendFloatBytes(udpClient, f4);
    SendFloatBytes(udpClient, COPx);
    SendFloatBytes(udpClient, COPy);
    SendFloatBytes(udpClient, W);
    udpClient.endPacket();

    // Also reset timer — matches what sinboard accidentally did
    t.fval = 0.0f;
    count  = 0;
    return;  // done — do not fall through to command parsing
  }

  // ── Store client address on every command packet too ─────────────────
  clientIP   = senderIP;
  clientPort = senderPort;
  python_discovered = true;

  Serial.print("[CMD] raw byte[0]=0x");
  Serial.println(incomingPacket[0], HEX);

  byte cmd = incomingPacket[0] & 0xF0;
  byte det = incomingPacket[0] & 0x0F;
  Serial.print("[CMD] cmd=0x"); Serial.print(cmd, HEX);
  Serial.print(" det=0x");      Serial.println(det, HEX);

  switch (cmd) {

    case STREAM_OFF:       // 0x10
      streaming = (det != 0x00);
      Serial.println(streaming ? "Stream ON" : "Stream OFF");
      break;

    case LED_RED_OFF:      // 0x20
      led_red = (det != 0x00);
      Serial.println(led_red ? "LED ON" : "LED OFF");
      UpdateRGBLED();
      break;

    case LED_GREEN_OFF:    // 0xA0
      led_green = (det != 0x00);
      UpdateRGBLED();
      break;

    case LED_BLUE_OFF:     // 0xB0
      led_blue = (det != 0x00);
      UpdateRGBLED();
      break;

    case MOTOR_OFF:        // 0x30
      if (det == 0x01) StartMotor();
      else {
        motor_running = false;
        digitalWrite(MOTOR_PIN, LOW);
        Serial.println("Motor OFF");
      }
      break;

    case RESET_TIMER:      // 0x40
      t.fval = 0.0f;
      count  = 0;
      Serial.println("Timer reset");
      break;

    case REGISTER: {       // 0x80
      // Use the captured IP/port — remoteIP() may be stale after read()
      serverIP   = senderIP;
      serverPort = senderPort;
      Serial.print("Server registered @ ");
      Serial.print(serverIP);
      Serial.print(":");
      Serial.println(serverPort);
      streaming = false;
      SendRegistrationRequest();
      break;
    }

    case SET_ID:           // 0x00
      Serial.print("ID set from "); Serial.print(id);
      id = det;
      Serial.print(" to "); Serial.println(id);
      if (id == 0) streaming = false;
      break;

    case GET_STATUS:       // 0x50
      Serial.println("Sending status.");
      SendSinglePacketforValidation();
      break;

    case RESET_BOARD:      // 0xC0
      Serial.println("RESET command — restarting...");
      Serial.flush(); delay(100);
      ESP.restart();
      break;

    default:
      Serial.print("[CMD] unknown command: 0x");
      Serial.println(cmd, HEX);
      break;
  }

  if (!streaming) individualpacket = true;
}

// ============================================================================
// SETUP
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n====================================");
  Serial.printf("ESP32 MOBBO Board ID: %d\n", BOARD_ID);
  Serial.println("ADS1261 ISR | Sinboard-compatible UDP");
  Serial.println("====================================\n");

  sampling_stats.reset();

  // GPIO
  pinMode(RED_LED_PIN,   OUTPUT); digitalWrite(RED_LED_PIN,   LOW);
  pinMode(GREEN_LED_PIN, OUTPUT); digitalWrite(GREEN_LED_PIN, LOW);
  pinMode(BLUE_LED_PIN,  OUTPUT); digitalWrite(BLUE_LED_PIN,  LOW);
  pinMode(MOTOR_PIN,     OUTPUT); digitalWrite(MOTOR_PIN,     LOW);
  pinMode(CS_PIN,        OUTPUT); digitalWrite(CS_PIN,        HIGH);
  pinMode(DRDY_PIN,      INPUT);
  pinMode(RESET_PIN,     OUTPUT); digitalWrite(RESET_PIN,     HIGH);
  pinMode(W_PIN,         INPUT_PULLUP);  // validation button, mirrors sinboard

  // Hardware reset ADS1261
  Serial.println("Resetting ADS1261...");
  digitalWrite(RESET_PIN, LOW);  delay(10);
  digitalWrite(RESET_PIN, HIGH); delay(100);

  // SPI
  hspi = new SPIClass(HSPI);
  hspi->begin(SCK_PIN, MISO_PIN, MOSI_PIN, CS_PIN);
  hspi->beginTransaction(spiSettings);

  // Verify ADS1261 chip ID
  spiBegin();
  hspi->transfer(ADS1261_CMD_RREG | ADS1261_REG_ID);
  hspi->transfer(0x00);
  uint8_t chip_id = hspi->transfer(0x00);
  spiEnd();
  Serial.print("ADS1261 chip ID: 0x"); Serial.println(chip_id, HEX);
  if ((chip_id & 0xF0) != 0x80) {
    Serial.println("ERROR: ADS1261 not found! Halting.");
    while (1) delay(1000);
  }

  ConfigADS();

  // WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.printf("Connecting to %s ", ssid);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println(" connected");
  Serial.print("IP: "); Serial.println(WiFi.localIP());

  udpClient.begin(localUdpPort);
  Serial.printf("UDP port %d\n", localUdpPort);

  // Zero-weight tare — mirrors sinboard setup() sequence
  Serial.println("\n*** Remove all weight from platform — calibrating... ***\n");
  delay(2000);
  sendCommand(ADS1261_CMD_START);
  delay(10);

  // Raw ADC tare (sinboard: GetLCOffsets)
  Lc1Off = GetLCoff(1, 2);
  Lc2Off = GetLCoff(3, 4);
  Lc3Off = GetLCoff(5, 6);
  Lc4Off = GetLCoff(7, 8);

  // Force tare (sinboard: GetForceOffset)
  f1off = GetForceoff(1, 2, gainB11, Lc1Off);
  f2off = GetForceoff(3, 4, gainB12, Lc2Off);
  f3off = GetForceoff(5, 6, gainB13, Lc3Off);
  f4off = GetForceoff(7, 8, gainB14, Lc4Off);

  Serial.print("f1Off: "); Serial.println(f1off);
  Serial.print("f2Off: "); Serial.println(f2off);
  Serial.print("f3Off: "); Serial.println(f3off);
  Serial.print("f4Off: "); Serial.println(f4off);

  sendCommand(ADS1261_CMD_STOP);
  delay(5);
  Serial.println("\nCalibration complete!");

  InitSensorVals();

  // Mirrors sinboard init state
  id               = 0x00;
  streaming        = true;
  individualpacket = false;
  led_red = led_green = led_blue = motor_running = false;
  prevLoopTime     = 0;

  ring_wr = ring_rd = 0;
  acq_paused = false;
  current_ch = 0;

  startAcq();

  Serial.println("\n====================================");
  Serial.printf("Board %d ready\n", BOARD_ID);
  Serial.println("====================================\n");
}

// ============================================================================
// MAIN LOOP  — mirrors sinboard loop() structure exactly
// ============================================================================
void loop() {

  // Read validation button — mirrors sinboard W_ButtonState read
  W_ButtonState.Ival = (int16_t)digitalRead(W_PIN);

  // Handle incoming UDP commands (non-blocking)
  ReceiveHandleIncomingData();

  // Flush ring buffer if ISR signalled overflow
  if (acq_paused) {
    stopAcq();
    processFrames();
    noInterrupts();
    acq_paused = false;
    ring_wr = ring_rd = 0;
    interrupts();
    startAcq();
  }

  // Drain ring buffer → update f1..f4
  uint32_t n = processFrames();
  if (n == 0) return;   // no new data — skip send (mirrors sinboard: no stale data)

  // Serial debug: force values (mirrors sinboard ReadLoadCellValues() print)
  Serial.print(f1.fval); Serial.print(",");
  Serial.print(f2.fval); Serial.print(",");
  Serial.print(f3.fval); Serial.print(",");
  Serial.print(f4.fval); Serial.print(",");

  sampling_stats.update();
  UpdateMotor();
  UpdateCOP();
  UpdateRGBLED();
  UpdateStatusBytes();

  Serial.print(",");
  Serial.print(W_ButtonState.Ival);

  // Update elapsed time and send — mirrors sinboard loop() exactly
  currLoopTime = millis();
  t.fval      += 0.001f * (currLoopTime - prevLoopTime);
  SendDeviceData();
  prevLoopTime = currLoopTime;
}
