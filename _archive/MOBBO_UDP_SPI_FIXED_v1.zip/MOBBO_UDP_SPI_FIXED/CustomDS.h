#ifndef CustomDS_h
#define CustomDS_h
#include "Arduino.h"

// ============================================================================
// UNION TYPES FOR BYTE-LEVEL ACCESS
// ============================================================================
typedef union {
  float num;
  uint8_t bytes[4];
} floatunion_t;

typedef union {
  int16_t num;
  uint8_t bytes[2];
} i2cval_t;

// ============================================================================
// Buffer Class - Circular buffer for time series data
// ============================================================================
class Buffer {
  public:
    Buffer();
    
    // Add a value to the buffer
    void add(float value);
    
    // Get current index
    byte inx(void);
    
    // Check if buffer is full (has wrapped around once)
    bool isFull(void);
    
    // Get value at index (filtered or raw)
    float val(byte index, bool filtered);
    float valf(byte index, bool filtered);
    
    // Set conversion factors (y = m*x + c)
    void setconvfac(float m, float c);
    
  private:
    static const byte N = 16;              // Buffer size (must be power of 2)
    static const byte Nmask = N - (byte)1; // Mask for wrapping
    
    float _m, _c;           // Conversion factors
    float _data[N];         // Raw data buffer
    float _dataf[N];        // Filtered data buffer
    byte _inx;              // Current index
    bool _full;             // Has buffer wrapped?
    byte _nf;               // Filter order
    float _acc;             // Accumulator
    
    float conval(float raw);  // Apply conversion
};

// ============================================================================
// OutDataBuffer4Float - Packs floats into byte array for transmission
// ============================================================================
class OutDataBuffer4Float {
  public:
    OutDataBuffer4Float();
    
    // Start a new packet
    void newPacket();
    
    // Add a float to the packet
    void add(float value);
    
    // Get number of floats in packet
    byte sz();
    
    // Get byte at index (for serial transmission)
    byte getByte(byte index);
    
  private:
    floatunion_t _data[64];  // Max 64 floats per packet
    byte _sz;                // Current size
};

#endif