#ifndef VARIABLE_UDP_H
#define VARIABLE_UDP_H

#include <WiFiUdp.h>
#include <WiFi.h>
#include "CustomDS.h"

// ============================================================================
// WIFI CREDENTIALS
// ============================================================================
const char* ssid     = "mocap";
const char* password = "12344321";

// ============================================================================
// PLATFORM DIMENSIONS (cm) — used in UpdateCOP()
//   L_HALF = half-length along X axis
//   B_HALF = half-breadth along Y axis
//   These must match the physical board geometry.
// ============================================================================
float L_HALF = 57.0f / 2.0f;   // 28.5 cm
float B_HALF = 42.0f / 2.0f;   // 21.0 cm

// ============================================================================
// CALIBRATION CONSTANTS — per-board, set once during manufacture
//   Force (N or kg depending on convention) = (raw - offset) * gain
//   gain  = 1 / SLOPE
//   offset contribution = -INTERCEPT / SLOPE
// ============================================================================
#define LC1_SLOPE      47366.70831f
#define LC2_SLOPE      53373.1518f
#define LC3_SLOPE      51475.3504f
#define LC4_SLOPE      50163.0491f

#define LC1_INTERCEPT  -104037.7332f
#define LC2_INTERCEPT   171089.7753f
#define LC3_INTERCEPT    34887.9779f
#define LC4_INTERCEPT   293133.0634f

float gainB11 = 1.0f / LC1_SLOPE;
float gainB12 = 1.0f / LC2_SLOPE;
float gainB13 = 1.0f / LC3_SLOPE;
float gainB14 = 1.0f / LC4_SLOPE;

float offB11 = LC1_INTERCEPT / LC1_SLOPE;
float offB12 = LC2_INTERCEPT / LC2_SLOPE;
float offB13 = LC3_INTERCEPT / LC3_SLOPE;
float offB14 = LC4_INTERCEPT / LC4_SLOPE;

// ============================================================================
// FILTERING — exponential moving average applied in processFrames()
//   1.0 = pass-through (no smoothing), 0.1 = heavy smoothing
// ============================================================================
const float SMOOTH_ALPHA = 1.0f;

// ============================================================================
// FORCE VALUE UNIONS — float ↔ byte array for UDP packing
// ============================================================================
union FloatBytes_ud {
  float fval;
  byte  fbytes[4];
};
FloatBytes_ud t;
FloatBytes_ud f1, f2, f3, f4;
FloatBytes_ud COPx, COPy, W;
FloatBytes_ud _zero;

// ============================================================================
// CALIBRATION OFFSETS (ADC counts measured at zero load)
// ============================================================================
float Lc1Off = 0.0f;
float Lc2Off = 0.0f;
float Lc3Off = 0.0f;
float Lc4Off = 0.0f;

float f1off = 0.0f;
float f2off = 0.0f;
float f3off = 0.0f;
float f4off = 0.0f;

// ============================================================================
// FILTERED FORCE VALUES — internal state for exponential moving average
// ============================================================================
float f1_filt = 0.0f;
float f2_filt = 0.0f;
float f3_filt = 0.0f;
float f4_filt = 0.0f;

// ============================================================================
// DEVICE STATUS
// ============================================================================
byte id      = 0xff;   // runtime id (0 = unregistered)
byte status1 = 0x00;   // bit7=RED, bit6=GREEN, bit5=BLUE, bit4=MOTOR, bit3=STREAM
byte status2 = 0x00;   // always = board_id (set in UpdateStatusBytes)
byte status3 = 0x00;   // reserved

bool streaming;
bool individualpacket;
bool led;       // kept for API compatibility — use led_red directly
bool vibrate;   // kept for API compatibility

// ============================================================================
// UDP COMMUNICATION
// ============================================================================
WiFiUDP          udpClient;
unsigned int     localUdpPort = 23000;
char             incomingPacket[32];
byte             rcvdByte;

IPAddress        serverIP(0, 0, 0, 0);
uint16_t         serverPort = 0;

// ============================================================================
// TIMING
// ============================================================================
unsigned long currLoopTime;
unsigned long prevLoopTime;
float         dT    = 0.0f;
uint16_t      count = 0;

// ============================================================================
// OUTPUT BUFFER (available but not used in the default stream path)
// ============================================================================
OutDataBuffer4Float outPayload;

// ============================================================================
// Discovery — stored client IP/port for reliable UDP replies.
// On ESP32, udpClient.remoteIP()/remotePort() can become stale after read().
// We capture the sender's IP/port on EVERY incoming packet and use these
// stored values in all Send*() functions — mirrors how sinboard's ESP8266
// always has a valid remoteIP() after parsePacket().
// ============================================================================
bool     python_discovered = false;
IPAddress clientIP(0, 0, 0, 0);
uint16_t  clientPort = 0;

#endif // VARIABLE_UDP_H